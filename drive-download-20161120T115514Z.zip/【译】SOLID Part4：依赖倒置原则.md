# 【译】SOLID Part 4：依赖倒置原则

[原文地址](https://code.tutsplus.com/tutorials/solid-part-4-the-dependency-inversion-principle--net-36872)

作者：Patkos Csaba

> 这篇博客是 [SOLID 原则](http://blog.csdn.net/u013538630/article/details/53143277) 的一部分
>
> [<< SOLID: Part 3 - 里氏代换原则 & 接口隔离原则](http://blog.csdn.net/u013538630/article/details/53151962)

[单一职责（SRP）](http://blog.csdn.net/u013538630/article/details/53118717)，[开闭原则](http://blog.csdn.net/u013538630/article/details/53151962)，里氏代换原则，接口隔离原则以及依赖倒转原则。在编程的过程中应当牢记这五种敏捷原则。

​	谈论 SOLID 原则中那个更重要是不公平的。但是可能没有哪个能比依赖倒置原则（下面简称 DIP）对你的代码造成更多的影响。如果你发现其它的原则难以运用，那就从依赖倒置原则开始，

## 定义

> A. 高层模块不应该依赖低层模块。两者都应该依赖于抽象
>
> B. 抽象不应该依赖于细节。

​	[Robert C. Martin](http://www.8thlight.com/our-team/robert-martin) 在他的书 [Agile Software Development, Principles, Patterns, and Practices](http://www.amazon.com/Software-Development-Principles-Patterns-Practices/dp/0135974445/ref=sr_1_1?s=books&ie=UTF8&qid=1378755964&sr=1-1&keywords=robert+c+martin) 中定义了这个原则。它是 SOLID 原则的最后一个。



## 现实世界中的 DIP

​	在开始写代码之前，我想告诉你一个故事。我们在 Syneto 不是一直都很关心我们的代码。几年前我们知道的不多并且觉得自己已经尽力了，我们的一些工程也做的不怎么样。我们来来回回的失败和尝试。

​	Uncle Bob（Robert C. Martin）的 SOLID 原则和整洁架构改变了我们的工作方式，将我们的代码从一种难以名状的状态拯救了回来。我将会通过讨论伴以例证的方式证明 DIP 能够带给你的进步。

​	大多数网页工程包含三个主要的技术：HTML，PHP 和 SQL。具体是哪个版本和哪种数据库和我们讨论的问题没有关系。我们关注的是网页上显示的内容来自数据库，两者通过 PHP 交互。

​	???

​	我见过很多工程在 HTML 的 PHP 标签里写 SQL 语句，或者是用 PHP 输出页面，然后在页面里读取 `$_GET` 和 `$_POST`。但是为什么这种写法是错的？

![](https://cdn.tutsplus.com/net/uploads/2014/02/html-php-sql-cross-dependencies.png)

​	上图形象的展示了刚刚讨论的情况。箭头代表显示的依赖，可以这么说，各个组件都依赖了其它所有组件。如果我们改变了数据库里的一张表，我们可能连 HTML 文件都要改。或者改变了 HTML 的一个 field，结果是要给数据库中的一个列改名字。再看第二张图表，我们需要改 PHP 文件如果 HTML 变了，在一些糟糕的情况下，当我们将 HTML 的内容都放在 PHP 文件里时，我们肯定要通过修改 PHP 文件来改变网页内容。毫无疑问的是，依赖存在于类和模块之间